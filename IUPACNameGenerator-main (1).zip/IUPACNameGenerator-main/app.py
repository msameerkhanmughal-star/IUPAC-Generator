from flask import Flask, render_template, request, jsonify
import requests
import urllib.parse

app = Flask(__name__)

def smiles_to_iupac(query: str):
    query = query.strip()
    
    subscript_map = {
        '₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4',
        '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9'
    }
    for subscript, normal in subscript_map.items():
        query = query.replace(subscript, normal)
    
    encoded = urllib.parse.quote(query, safe='')
    
    has_smiles_chars = any(c in query for c in "=()[]#@")
    has_digits = any(c.isdigit() for c in query)
    has_lowercase = any(c.islower() for c in query)
    
    if has_smiles_chars or (has_lowercase and has_digits):
        url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/smiles/{encoded}/property/IUPACName/JSON"
    else:
        url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{encoded}/property/IUPACName/JSON"
    
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}
    
    try:
        data = resp.json()
        props = data.get("PropertyTable", {}).get("Properties", [])
        if not props:
            return {"error": "No IUPAC name found for this input."}
        iupac = props[0].get("IUPACName")
        if not iupac:
            return {"error": "PubChem returned no IUPACName field."}
        return {"iupac": iupac}
    except ValueError:
        return {"error": "Invalid JSON from PubChem."}

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/api/convert", methods=["POST"])
def convert():
    data = request.json or {}
    query = data.get("smiles") or request.form.get("smiles", "")
    if not query:
        return jsonify({"error": "Please provide a chemical structure, formula, or name."}), 400
    result = smiles_to_iupac(query)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
