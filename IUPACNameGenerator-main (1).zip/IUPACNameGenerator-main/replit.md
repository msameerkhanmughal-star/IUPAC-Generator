# IUPAC Nomenclature Generator

## Overview

This is a Flask-based web application that converts chemical structures, formulas, and compound names into IUPAC (International Union of Pure and Applied Chemistry) chemical nomenclature. The application provides a simple web interface where chemistry students can input:
- SMILES notation (e.g., CC(=O)C, c1ccccc1)
- Compound names (e.g., aspirin, caffeine)
- Simple molecular formulas (e.g., H2O)

The app queries the PubChem REST API to retrieve the corresponding IUPAC name.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single-Page Application**: Uses vanilla HTML/CSS with minimal JavaScript for a straightforward user experience
- **Responsive Design**: Mobile-first approach with flexbox for centering and responsive layouts
- **Client-Side Validation**: Basic input validation before making API requests
- **Asynchronous Communication**: Uses fetch API to communicate with the backend without page reloads

### Backend Architecture
- **Framework**: Flask (Python) - chosen for its simplicity and lightweight nature, ideal for small web applications
- **API Design**: RESTful API with a single POST endpoint (`/api/convert`) that accepts JSON payloads
- **Stateless Architecture**: No session management or database - each request is independent
- **Error Handling**: Comprehensive exception handling with specific HTTP status codes and user-friendly error messages
- **Smart Input Detection**: Automatically determines whether input is SMILES notation, compound name, or molecular formula

### Request Flow
1. User enters chemical structure (SMILES), compound name, or formula through the web interface
2. Frontend sends POST request to `/api/convert` endpoint with JSON payload
3. Backend analyzes input to determine the appropriate PubChem API endpoint:
   - SMILES endpoint: for inputs with special characters (=, (), [], #, @) or aromatic notation (lowercase + digits)
   - Name endpoint: for compound names and simple molecular formulas
4. Backend URL-encodes the input and queries the appropriate PubChem API endpoint
5. Response is parsed and IUPAC name is extracted
6. Result or error message is returned to the frontend as JSON

### Design Decisions
- **No Database**: The application is stateless and doesn't persist any data, making it simple to deploy and maintain
- **Direct API Integration**: Rather than storing chemical data locally, the app acts as a proxy to PubChem, ensuring always up-to-date information
- **Synchronous Processing**: Each request is handled synchronously as chemical name lookups are typically fast (<10 seconds)
- **Embedded Templates**: HTML templates are stored in the Flask `templates/` directory following Flask conventions

## External Dependencies

### Third-Party APIs
- **PubChem REST API** (`pubchem.ncbi.nlm.nih.gov`): Primary data source for converting chemical structures to IUPAC names
  - SMILES Endpoint: `/rest/pug/compound/smiles/{smiles}/property/IUPACName/JSON`
  - Name Endpoint: `/rest/pug/compound/name/{name}/property/IUPACName/JSON`
  - Authentication: None required (public API)
  - Rate Limiting: Subject to PubChem's usage policies
  - Timeout: 10 seconds configured for requests

### Python Dependencies
- **Flask**: Web framework for routing and serving HTML templates
- **requests**: HTTP library for making API calls to PubChem
- **urllib.parse**: Standard library module for URL encoding SMILES strings

### Deployment Configuration
- **Host**: Configured to run on `0.0.0.0` to accept connections from any network interface
- **Port**: 5000 (standard Flask development port)
- **Debug Mode**: Disabled for production safety

### Browser Requirements
- Modern browser with fetch API support
- JavaScript enabled for form submission and result display